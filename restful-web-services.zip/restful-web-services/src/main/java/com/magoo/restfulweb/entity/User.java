package com.magoo.restfulweb.entity;

import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="user")
public class User {

	@Id
	@GeneratedValue
	private Integer id;
	
	@Size(min=2, message="Name should have atleast 2 characters")
	private String name;
	private Date birthDate;
	
	private String userName;
	
	private String email;
	@Embedded
	private Address address;
	@Embedded
	private Company company;
	
	//@OneToMany(mappedBy="user")
	//private List<Post> posts;
	
	

	public User()
	{
		
	}
	
	

	public User(Integer id, String name,
			Date birthDate, String userName, String email, Address address, Company company) {
		super();
		this.id = id;
		this.name = name;
		this.birthDate = birthDate;
		this.userName = userName;
		this.email = email;
		this.address = address;
		this.company = company;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
		
	}
	
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
	

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", birthDate=" + birthDate + ", userName=" + userName + ", email="
				+ email + ", address=" + address + ", company=" + company +  "]";
	}

	
	
}
