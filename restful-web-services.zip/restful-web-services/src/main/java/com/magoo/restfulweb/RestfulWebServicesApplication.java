package com.magoo.restfulweb;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

@SpringBootApplication
public class RestfulWebServicesApplication {
  
	static Logger logger=LoggerFactory.getLogger(RestfulWebServicesApplication.class);
	
	public static void main(String[] args) {
		
		logger.info("Entering inside main()");
		SpringApplication.run(RestfulWebServicesApplication.class, args);
	}
	
	

}
