package com.magoo.restfulweb.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.magoo.restfulweb.entity.Address;
import com.magoo.restfulweb.entity.Company;
import com.magoo.restfulweb.entity.User;

@Component
public class UserDaoService {
	
	
	private static Logger logger=LoggerFactory.getLogger(UserDaoService.class);
	
	
	private static List<User> list=new ArrayList<>();
	private static int count=3;
	
	static
	{
		logger.info("Going inside adding values");
		
		list.add(new User(1,"Adam",new Date(),"ABC","ABC@gmail.com",new Address("XYZ","DEF","LADAKH","HP"),new Company("GHT","JHU","POI")));
		list.add(new User(2,"Pew",new Date(),"ABC","ABC@gmail.com",new Address("XYZ","DEF","LADAKH","HP"),new Company("GHT","JHU","POI")));
		list.add(new User(3,"John",new Date(),"ABC","ABC@gmail.com",new Address("XYZ","DEF","LADAKH","HP"),new Company("GHT","JHU","POI")));
		
		logger.info("Going out after adding values");
	}
	
	public List<User> getAllUsers()
	{
		logger.info("inside getAllUsers()  method");
		return list;
	}
	
	public User save(User user)
	{
		
		logger.info("Going inside save() method");
		if(user.getId()==null)
		{
			user.setId(++count);
		}
		list.add(user);
		
		logger.info("Going outside save() method");
		return user;
	}
	
	
	public User findOne(int id)
	{
		logger.info("Going inside findOne() method");
		for(User user:list)
		{
			if(user.getId()==id)
			{
				return user;
			}
		}

		logger.info("Going outside findOne() method");
		return null;
		
	}
	
	public User deleteById(int id)
	{
		Iterator<User> iterator=list.iterator();
		while(iterator.hasNext())
		{
			User us=iterator.next();
			if(us.getId()==id)
			{
				iterator.remove();
			}
			return us;
		}
		return null;
	}
	
	

}
