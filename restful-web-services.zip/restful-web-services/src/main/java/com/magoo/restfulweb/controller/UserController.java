package com.magoo.restfulweb.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.magoo.restfulweb.entity.Post;
import com.magoo.restfulweb.entity.User;
import com.magoo.restfulweb.exception.UserNotFoundException;
import com.magoo.restfulweb.repository.PostRepository;
import com.magoo.restfulweb.repository.Userrepository;
import com.magoo.restfulweb.service.UserDaoService;

@RestController
public class UserController {
	
	private static Logger logger=LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserDaoService service;
	
	@Autowired
	private Userrepository userRepository;

	@Autowired
	private PostRepository postrepository; 
	
	// retrieve all users
	@GetMapping("/users")
	public List<User> retrieveAllUsers()
	{
		logger.info("Inside retrieveAllUsers() method");
		
		return userRepository.findAll();
	}
	
	
	@GetMapping("/users/{id}")
	public Optional<User> getUser(@PathVariable int id)
	{
		logger.info("Inside getUser() method");
		
        Optional<User> user=userRepository.findById(id);
        if(user==null)
        {
        	throw new UserNotFoundException("id"+id);
        
        }
       
        return user;
	}
	
	// creating a user
	
	@PostMapping("/users")
	public ResponseEntity createUser(@Valid @RequestBody User user)
	{
		logger.info("Inside createUser() method");
		User saveduser=userRepository.save(user);
		
	    URI location=	ServletUriComponentsBuilder.fromCurrentRequest().
			        path("/{id}").buildAndExpand(saveduser.getId())
			        .toUri();
	 
	 return ResponseEntity.created(location).build();
	 
	}
	
	
	@DeleteMapping("/users/{id}")
	public void delete(@PathVariable int id)
	{
		logger.info("Inside delete() method");
		
		userRepository.deleteById(id);
		
		logger.info("Outside delete method");
	}
	
	
	
	// create a new post for a user
	
	@PostMapping("/users/{id}/posts")
	public ResponseEntity<Object> createPost(@PathVariable int id,@RequestBody Post post)
	{
		Optional<User> userOp=userRepository.findById(id);
		
		if(!userOp.isPresent())
		{
			throw new UserNotFoundException("id"+id);
		}
		
		User user=userOp.get();
		
		post.setUser(user);
		
		postrepository.save(post);
		
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().
		        path("/{id}").buildAndExpand(post.getId())
		        .toUri();
		
		
		return ResponseEntity.created(location).build();
		
	}
}
